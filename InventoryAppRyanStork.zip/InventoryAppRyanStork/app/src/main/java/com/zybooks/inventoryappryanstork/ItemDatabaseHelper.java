package com.zybooks.inventoryappryanstork;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class ItemDatabaseHelper extends SQLiteOpenHelper {


    public static final String ITEM_TABLE = "ITEM_TABLE";
    public static final String COLUMN_UPC = "UPC";
    public static final String COLUMN_NAME = "NAME";
    public static final String COLUMN_QUANTITY = "QUANTITY";

    public ItemDatabaseHelper(@Nullable Context context) {
        super(context, "Items.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTableStatement = "CREATE TABLE " + ITEM_TABLE + " (" + COLUMN_UPC + " TEXT PRIMARY KEY, " + COLUMN_NAME + " TEXT, " + COLUMN_QUANTITY + " INT)";
        db.execSQL(createTableStatement);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public boolean addItem (Item newItem){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_UPC, newItem.getUPC());
        values.put(COLUMN_NAME, newItem.getName());
        values.put(COLUMN_QUANTITY,newItem.getQuantity());
        long insert = db.insert(ITEM_TABLE, null, values);
        if (insert == -1){
            return false;
        }
        else {
            return true;
        }
    }

    public List<Item> allItems(){
        List<Item> returnItems = new ArrayList<>();
        String queryString = "SELECT * FROM " + ITEM_TABLE;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(queryString, null);

        if (cursor.moveToFirst()){
            do {
                String UPC = cursor.getString(0);
                String name = cursor.getString(1);
                int quantity = cursor.getInt(2);
                Item newItem = new Item(UPC, name, quantity);
                returnItems.add(newItem);
            } while (cursor.moveToNext());
        }
        else {
            //We have an empty Database
        }
        cursor.close();
        db.close();

        return returnItems;
    }

    public boolean deleteItem (Item item){
        SQLiteDatabase db = this.getWritableDatabase();
        String queryString = "DELETE FROM " + ITEM_TABLE + " WHERE " + COLUMN_UPC + " = " + item.getUPC();
        Cursor cursor = db.rawQuery(queryString, null);
        if (cursor.moveToFirst()){
            return true;
        }
        else {
            return false;
        }
    }
}
