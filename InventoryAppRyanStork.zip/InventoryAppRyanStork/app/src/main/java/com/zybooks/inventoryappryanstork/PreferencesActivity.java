package com.zybooks.inventoryappryanstork;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.Toast;
import android.widget.ToggleButton;

public class PreferencesActivity extends AppCompatActivity {
    private static final int PERMISSION_REQUEST_SMS = 0;
    Button mReturnButton;
    Switch mSMSRequest;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preferences);
        mReturnButton = findViewById(R.id.buttonReturn);
        mSMSRequest = findViewById(R.id.SMSRequest);
        if (ContextCompat.checkSelfPermission(this,Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED){

        }
        mSMSRequest.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                Toast.makeText(PreferencesActivity.this, "CHECK CHANGE", Toast.LENGTH_SHORT).show();
                requestSmsPermission();
            }
        });
    }


    public void ReturnButtonClick(View v) {
        Intent i = new Intent(getApplicationContext(), InventoryActivity.class);
        startActivity(i);
        finish();
    }

    private void requestSmsPermission() {
        String permission = Manifest.permission.READ_SMS;
        int grant = ContextCompat.checkSelfPermission(this, permission);
        if (grant != PackageManager.PERMISSION_GRANTED) {
            String[] permission_list = new String[1];
            permission_list[0] = permission;
            ActivityCompat.requestPermissions(this, permission_list, 1);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(PreferencesActivity.this, "permission granted", Toast.LENGTH_SHORT).show();


            } else {
                Toast.makeText(PreferencesActivity.this, "permission not granted", Toast.LENGTH_SHORT).show();
            }
        }
    }
}