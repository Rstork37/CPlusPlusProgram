package com.zybooks.inventoryappryanstork;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class InventoryActivity extends AppCompatActivity {
    EditText mUPC;
    EditText mName;
    EditText mQuantity;
    Button mAdd;
    ListView mItems;

    ArrayAdapter itemArrayAdapter;
    List<Item> allItems;
    ItemDatabaseHelper itemDatabaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);
        mUPC = findViewById(R.id.etUPC);
        mName = findViewById(R.id.etName);
        mQuantity = findViewById(R.id.etQty);
        mAdd = findViewById(R.id.buttonAdd);
        mItems = findViewById(R.id.lv_Items);
        itemDatabaseHelper = new ItemDatabaseHelper(InventoryActivity.this);
        updateItemList();
        mItems.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Item clickItem = (Item) parent.getItemAtPosition(position);
                itemDatabaseHelper.deleteItem(clickItem);
                updateItemList();
                mUPC.setText(clickItem.getUPC());
                mName.setText(clickItem.getName());
                mQuantity.setText(String.valueOf(clickItem.getQuantity()));
            }
        });
    }

    public void AddButtonClick(View v){
        String UPC = String.valueOf(mUPC.getText());
        String name = String.valueOf(mName.getText());
        String qtyString = String.valueOf(mQuantity.getText());
        itemDatabaseHelper = new ItemDatabaseHelper(InventoryActivity.this);
        int quantity;

        if (qtyString.length() == 0){
            quantity = 0;
        }
        else {
            quantity = Integer.valueOf(String.valueOf(mQuantity.getText()));
        }

        if ((UPC.length()>0) && (name.length() > 0) && (quantity > 0)){
            Item newItem = new Item(UPC, name, quantity);
            boolean success = itemDatabaseHelper.addItem(newItem);
            if (success){

                Toast.makeText(InventoryActivity.this, "ITEM ADDED SUCCESSFULLY",Toast.LENGTH_SHORT).show();
                mUPC.setText("");
                mName.setText("");
                mQuantity.setText("");
            }
            else {
                Toast.makeText(InventoryActivity.this,"FAILED: ITEM ALREADY EXISTS",Toast.LENGTH_SHORT).show();
            }
        }
        else {
            Toast.makeText(InventoryActivity.this,"INPROPER INPUTS, PLEASE FIX",Toast.LENGTH_SHORT).show();
        }
        updateItemList();
    }

    public void SMSButtonClick(View v){
        Intent i = new Intent(getApplicationContext(), PreferencesActivity.class);
        startActivity(i);
    }

    private void updateItemList() {
        itemArrayAdapter = new ArrayAdapter<Item>(InventoryActivity.this, android.R.layout.simple_list_item_1, itemDatabaseHelper.allItems());
        mItems.setAdapter(itemArrayAdapter);
    }


}