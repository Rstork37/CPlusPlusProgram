package com.zybooks.inventoryappryanstork;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class LoginActivity extends AppCompatActivity {
    Button mLogInButton;
    EditText mUsername;
    EditText mPassword;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        mLogInButton = findViewById(R.id.buttonCreate);
        mUsername = findViewById(R.id.EditTextUsername);
        mPassword = findViewById(R.id.EditTextPassword);

    }

    public void CreateButtonClick(View v) {
        String username = String.valueOf(mUsername.getText());
        String password = String.valueOf(mPassword.getText());
        if (username.length() >0 && password.length() > 0){
            UsernameDatabaseHelper usernameDatabaseHelper = new UsernameDatabaseHelper(LoginActivity.this);
            UsernameDatabase newUser = new UsernameDatabase(username, password);
            boolean success = usernameDatabaseHelper.addUser(newUser);
            if (success){
                Toast.makeText(LoginActivity.this, "USER ADDED", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(getApplicationContext(), InventoryActivity.class);
                startActivity(i);
                finish();
            }
            else {
                Toast.makeText(LoginActivity.this, "USER ALREADY EXISTS", Toast.LENGTH_SHORT).show();
            }

        }
    }

    public void LogInButtonClick(View v){
        String username = String.valueOf(mUsername.getText());
        String password = String.valueOf(mPassword.getText());
        if (username.length() > 0 && password.length() > 0) {
            UsernameDatabaseHelper usernameDatabaseHelper = new UsernameDatabaseHelper(LoginActivity.this);
            List<UsernameDatabase> allUsers = new ArrayList<>();
            UsernameDatabase loopUser = new UsernameDatabase();
            allUsers = usernameDatabaseHelper.allUsers();
            boolean userMatch = false;
            for (int i = 0; i < allUsers.size(); i++) {
                loopUser.setUsername(allUsers.get(i).getUsername());
                loopUser.setPassword(allUsers.get(i).getPassword());
                if (username.equals(loopUser.getUsername())){
                    if (password.equals(loopUser.getPassword())){
                        userMatch = true;
                    }
                }
            }
            if (userMatch){
                Toast.makeText(LoginActivity.this, "USER FOUND", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(getApplicationContext(), InventoryActivity.class);
                startActivity(i);
                finish();
            }
            else {
                Toast.makeText(LoginActivity.this, "CREDENTIALS NOT FOUND", Toast.LENGTH_SHORT).show();
            }
        }
    }

}
