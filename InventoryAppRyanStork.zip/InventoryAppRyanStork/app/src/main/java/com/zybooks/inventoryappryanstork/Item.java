package com.zybooks.inventoryappryanstork;

public class Item {
    private String UPC;
    private String name;
    private int quantity;

    public Item(String UPC, String name, int quantity) {
        this.UPC = UPC;
        this.name = name;
        this.quantity = quantity;
    }

    @Override
    public String toString() {
        return UPC + "        " + name + "             " + quantity;
    }

    public String getUPC() {
        return UPC;
    }

    public void setUPC(String UPC) {
        this.UPC = UPC;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}
