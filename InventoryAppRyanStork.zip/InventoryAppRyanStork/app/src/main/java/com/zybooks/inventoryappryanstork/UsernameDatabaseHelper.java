package com.zybooks.inventoryappryanstork;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class UsernameDatabaseHelper extends SQLiteOpenHelper {

    public static final String USERS_TABLE = "USERS_TABLE";
    public static final String COLUMN_USERNAME = "USERNAME";
    public static final String COLUMN_PASSWORD = "PASSWORD";

    public UsernameDatabaseHelper(@Nullable Context context) {
        super(context, "Users.db", null, 1);
    }

    //The first time the database is accessed
    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTableStatement = "CREATE TABLE " + USERS_TABLE + " (" + COLUMN_USERNAME + " TEXT PRIMARY KEY, " + COLUMN_PASSWORD + " TEXT)";
        db.execSQL(createTableStatement);

    }

    //When the database version number changes
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public boolean addUser(UsernameDatabase usernameDatabase) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, usernameDatabase.getUsername());
        values.put(COLUMN_PASSWORD, usernameDatabase.getPassword());
        long insert = db.insert(USERS_TABLE, null, values);
        if (insert == -1){
            return false;
        }
        else {
            return true;
        }
    }

    public List<UsernameDatabase> allUsers() {
        List<UsernameDatabase> returnList = new ArrayList<>();

        String queryString = "SELECT * FROM " + USERS_TABLE;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(queryString, null);

        if (cursor.moveToFirst()){
            do {
                String username = cursor.getString(0);
                String password = cursor.getString(1);
                UsernameDatabase newUser = new UsernameDatabase(username,password);
                returnList.add(newUser);
            } while (cursor.moveToNext());
        }
        else {
            //We have an empty Database
        }
        cursor.close();
        db.close();
        return returnList;
    }
}
