/*
 * Oviparous.cpp
 *
 *  Created on: Aug 11, 2020
 *      Author: Ryan Stork
 *      Detail: These are the functions of the Oviparous class
 */

#include <iostream>
#include <string>
#include "Oviparous.h"
using namespace std;


//Default Constructor
Oviparous::Oviparous(){
	numberOfEggs = 0;
}

//Prints the contents of the Oviparous to the screen
void Oviparous::PrintItem(){
	cout << tagID << " "<< name << "   " << numberOfEggs << endl;
}

//Returns Oviparous         , which is the animal type
string Oviparous::GetType() const {
	return "Oviparous      ";
}

//Sets the number of eggs the oviparous currently has
void Oviparous::SetNumberOfEggs(int numberOfEggs){
	this->numberOfEggs = numberOfEggs;
}

//Returns the number of eggs the oviparous currently has
int Oviparous::GetNumberOfEggs() const {
	return numberOfEggs;
}
