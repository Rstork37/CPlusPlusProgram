/*
 * Animal.h
 *
 *  Created on: Aug 11, 2020
 *      Author: Ryan Stork
 *      Detail: This is the definition of the animal class
 *      			Animal() - Default constructor
 *      			SetName() - Set the name of the animal
 *      			PrintItem() - Print the item details to the screen, this is a virtual item, which will be overridden by derived classes
 *      			GetName() - Returns the name of the animal
 *      			SetID() - Set the tracking number of the animal
 *      			GetID() - Returns the tracking number of the animal
 *      			PrintToFile() - Returns the contents of the variables.  This is a virtual item, which will be overridden by derived classes
 *				With 2 protected members
 *					string name - the name of the animal
 *					string tagID - the tracking number of the animal
 */

#include <string>
using namespace std;

#ifndef ANIMAL_H_
#define ANIMAL_H_


class Animal {
	public:
		Animal();								//Default constructor
		void SetName(string name);				//Setting the name of the animal
		void SetID(string ID);					//Setting the tracking number of the animal
		string GetID() const;					//Return the tracking number of the animal
		string GetName() const;					//Return the name of the animal
		virtual void PrintItem();				//A virtual function that will be overridden by derived classes.  Prints contents to the screen
		virtual string PrintToFile() const;		//A virtual function that will be overridden by derived classes.  Returns a string of all the protected members
		virtual ~Animal(){};					//A virtual destructor to go with the virtual items to not cause a compiler warning


	protected:
		string name;							//The name of the animal
		string tagID;							//The tracking number of the animal



};



#endif /* ANIMAL_H_ */
