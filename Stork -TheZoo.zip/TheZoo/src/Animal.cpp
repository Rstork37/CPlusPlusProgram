/*
 * Animal.cpp
 *
 *  Created on: Aug 11, 2020
 *      Author: Ryan Stork
 *      Detail: This is the functions of the animal class
 *      			Animal() - Default constructor
 *      			SetName() - Set the name of the animal
 *      			PrintItem() - Print the item details to the screen, this is a virtual item, which will be overridden by derived classes
 *      			GetName() - Returns the name of the animal
 *      			SetID() - Set the tracking number of the animal
 *      			GetID() - Returns the tracking number of the animal
 *      			PrintToFile() - Returns the contents of the variables.  This is a virtual item, which will be overridden by derived classes
 *
 */

#include <iostream>
#include <string>
#include "Animal.h"
using namespace std;


//Default Constructor
Animal::Animal(){
	name = "";
	tagID = "";
}

//Setting the name of the animal
void Animal::SetName(string name){
	this->name = name;
}

//Printing the name of the animal.  This will be overridden by derived classes
void Animal::PrintItem(){
	cout << tagID << "     " << name << endl;
}
//Returns the name of the animal
string Animal::GetName() const {
	return name;
}

//Set the tracking number of the animal
void Animal::SetID(string ID){
	this->tagID = ID;
}

//Returns the tracking number of the animal
string Animal::GetID() const {
	return tagID;
}

//Returns a string of all the contents.  This will be overridden by derived classes
string Animal::PrintToFile() const {
	string allData;
	allData = tagID + name;
	return allData;
}
