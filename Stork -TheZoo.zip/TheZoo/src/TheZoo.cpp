/*
 *	Author: 	Ryan Stork
 *	Date:		8/13/2020
 *	Details:	This is the main program for our zoo system.
 *				We display the main menu, where the user makes a menu choice
 *					Load Animal Data - 		Loads a list of animals from "zoodata.txt"
 *					Generate Data - 		If you are using the system for the first time, this is a java program that can create "zoodata.txt"
 *					Display Animal Data - 	Prints out a formatted file of the animals currently in the system
 *					Add Record - 			Adds an animal to the list
 *					Delete Record - 		Remove an animal from the list
 *					Save Animal Data - 		Saves all animals in the list to "zoodata.txt"
 *					Quit - 					Quits the program
 */

#include <vector>			//We use a vector of Animal Pointers for the list
#include <iostream>			//We are manipulating the input and output
#include <jni.h>			//This library communicates with Java
#include <fstream>			//This allows us to write to files

#include "Animal.h"			//Our animal class
#include "Mammal.h"			//Mammal is a derived class of animal
#include "Oviparous.h"		//Oviparous is a derived class of animal
#include "Crocodile.h"		//Crocodile is a derived class of Oviparous
#include "Pelican.h"		//Pelican is a derived class of Oviparous
#include "Goose.h"			//Goose is a derived class of Oviaprous
#include "Whale.h"			//Whale is a derived class of Mammal
#include "Bat.h"			//Bat is a derived class of Mammal
#include "SeaLion.h"		//SeaLion is a derived class of SeaLion
using namespace std;

void GenerateData()               //DO NOT TOUCH CODE IN THIS METHOD
{
     JavaVM *jvm;                      // Pointer to the JVM (Java Virtual Machine)
     JNIEnv *env;                      // Pointer to native interface
                                                              //================== prepare loading of Java VM ============================
     JavaVMInitArgs vm_args;                        // Initialization arguments
     JavaVMOption* options = new JavaVMOption[1];   // JVM invocation options
     options[0].optionString = (char*) "-Djava.class.path=";   // where to find java .class
     vm_args.version = JNI_VERSION_1_6;             // minimum Java version
     vm_args.nOptions = 1;                          // number of options
     vm_args.options = options;
     vm_args.ignoreUnrecognized = false;     // invalid options make the JVM init fail
                                                                          //=============== load and initialize Java VM and JNI interface =============
     jint rc = JNI_CreateJavaVM(&jvm, (void**)&env, &vm_args);  // YES !!
     delete options;    // we then no longer need the initialisation options.
     if (rc != JNI_OK) {
            // TO DO: error processing...
            cin.get();
            exit(EXIT_FAILURE);
     }
     //=============== Display JVM version =======================================
     cout << "JVM load succeeded: Version ";
     jint ver = env->GetVersion();
     cout << ((ver >> 16) & 0x0f) << "." << (ver & 0x0f) << endl;

     jclass cls2 = env->FindClass("ZooFileWriter");  // try to find the class
     if (cls2 == nullptr) {
            cerr << "ERROR: class not found !";
     }
     else {                                  // if class found, continue
            cout << "Class MyTest found" << endl;
            jmethodID mid = env->GetStaticMethodID(cls2, "createZooFile", "()V");  // find method
            if (mid == nullptr)
                   cerr << "ERROR: method void createZooFile() not found !" << endl;
            else {
                   env->CallStaticVoidMethod(cls2, mid);                      // call method
                   cout << endl;
            }
     }


     jvm->DestroyJavaVM();
     cin.get();
}


//*******************************************************************************************************************
/*
 *	In this module, we are adding an animal to the list
 *	We take in a vector of Animal Pointers, and return the possibly updated list if we added an animal
 */

vector<Animal*> AddAnimal(vector<Animal*> animalList)
{
	string tagID;						//Tracking ID input from the user
	string name;						//Animal name input from the user
	string animalChoice = "";			//A variable used where the user chooses which animal they want to add
	string entryConfirmation = "";		//A variable used to make sure that the user wants to add an animal
	Bat* newBat;						//A bat pointer if the user wants to add a bat
	Crocodile* newCroc;					//A crocodile pointer if the user wants to add a crocodile
	Goose* newGoose;					//A goose pointer if the user wants to add a goose
	Pelican* newPelican;				//A pelican pointer if the user wants to add a pelican
	SeaLion* newSeaLion;				//A sealion pointer if the user wants to add a sealion
	Whale* newWhale;					//A whale pointer if the user wants to add a whale
	int numOfEggs = -1;					//Part of the Oviparous class, which lays eggs, set to -1 to enter the loop
	int nurse = 2;						//Part of the Mammal class, which nurses its young, set to 2 to enter the loop
	bool isValidID = false;				//Boolean value used to verify a valid tracking number
	bool isValidName = false;			//Boolean value used to verify a valid name
	bool isValidAnimalChoice = false;	//Between the choice of 6 animals, did the user choose one of those values
	bool isValidConfirmation = false;	// Y/N confirmation if the user wants to add an animal


	//In this loop, the user enter a tracking number.
	//We will use the isValidID as a check to see if the user entered a valid tracking number
	cout << "ADD ANIMAL:" << endl << endl;
    while (!isValidID) {						//We enter and repeat the loop if the user had an invalid input
    	isValidID = true;						//We set the value to true, only if there is an invalid input, will it turn this value to false.
    	cout << "Enter Tracking Number (Up to 6 digits):";
        getline(cin,tagID);						//We use the getline function in case the user decides to press the space key
        if (tagID.size() == 0){					//If the user just pressed enter without typing in anything, then they had a bad entry
        	isValidID = false;
        	cout << "Invalid ID, no entry found" << endl << endl;
        }
        if (tagID.size() > 6) {					//If the user entered in too large of a tracking number, then they had a bad entry and need to reenter a new tracking number
        	isValidID = false;
        	cout << "Invalid ID, size too large" << endl << endl;
        }
        if (tagID.size() < 6) {					//If the user only entered a number like 55, this loop will make it 0000055, which could match our tracking number
        	while (tagID.size() < 6) {
        		tagID = "0" + tagID;
        	}
        }
        if (isValidID){							//If they had a valid entry to this point, then we will test each character for proper input

        	//We will loop through every character to make sure that all characters are a number 0-9
        	//If a bad character is found, it will tell the user which character was bad and ask to reenter a new tracking number
        	for (unsigned int i = 0; i < tagID.size(); ++i){
        		if ((tagID.at(i) != '0') && (tagID.at(i) != '1') && (tagID.at(i) != '2') &&
        			(tagID.at(i) != '3') && (tagID.at(i) != '4') && (tagID.at(i) != '5') &&
        			(tagID.at(i) != '7') && (tagID.at(i) != '8') && (tagID.at(i) != '9')) {

        			isValidID = false;
        			cout << "Invalid Character found in ID: " << tagID.at(i) << endl << endl;
        		}
        	}
        }

        //In this section we will test to see if the tracking number that was input was already a tracking number that was used
        if (isValidID) {
        	for (unsigned int i = 0; i < animalList.size();++i) {
        		//To compare strings we should use the .compare method.
        		//We compare the tagID with the current iteration in our list
        		//A result of 0 means that it was a match and the user must enter another tracking number
        		if (tagID.compare(animalList.at(i)->GetID()) == 0){
        			isValidID = false;
        			cout << "Tracking Number already used, please enter another ID" << endl << endl;
        		}
        	}
        }
    };


    //This loop we will get the name of the animal from the user
    //We will test its validity before the user can progress
    while (!isValidName) {
    	isValidName = true;			//The value is set to true, only if it is tested to be invalid, will it change
    	cout << "Enter Name (15 character max): ";
    	getline(cin,name);			//We use the getline function in case the user enters a space
    	if (name.size() == 0) {		//If the user just pressed enter, the entry is invalid and must be reentered
    		isValidName = false;
    		cout << "Invalid Entry, no name found" << endl << endl;
    	}
    	if (name.size() > 15) {		//If the name is too large, then the entry is invalid and must be reentered
    		isValidName = false;
    		cout << "Invalid Entry, name too large" << endl << endl;
    	}
    	if (isValidName){			//if the name that was entered was valid, spaces are added to the end of the name until the name is 15 characters
    		while (name.size() < 15){
    			name = name + " ";
    		}
    	}
    }

    //The user will choose from one of the 6 animals in the current system.
    cout << "Choose which animal:" << endl;
    cout << "   Mammal:" << endl;
    cout << "      1. Bat" << endl;
    cout << "      2. SeaLion" << endl;
    cout << "      3. Whale" << endl;
    cout << "   Oviaparous:" << endl;
    cout << "      4. Crocodile" << endl;
    cout << "      5. Goose" << endl;
    cout << "      6. Pelican" << endl << endl;

    //We test if the choice the entered was valid
    while (!isValidAnimalChoice){
    	cout << "==>";
    	getline(cin,animalChoice);
    	isValidAnimalChoice = true;				//Value changed to true, must be proven false if the user entered an invalid input
    	if (animalChoice.size() == 0) {			//If the user just pressed enter without typing, the input is invalid and must be reentered
    		isValidAnimalChoice = false;
    		cout << "Invalid Entry, please enter a choice" << endl;
    	}

    	//If the user typed in '1' then we will run this section
    	if (animalChoice.compare("1") == 0){
    		while ((nurse != 0) && (nurse != 1)){						//The user must enter a 1 or a 0 for nursing
    			cout << "Is the Bat nursing? (1 for yes, 0 for no):";
    			cin >> nurse;
    		}
    		//We repeat the information that we got from the user back to them
    		//Then we will ask for confirmation that they want to add this animal into the list
    		cout << "Please Confirm, We are adding a Bat to the system" << endl;
    		cout << "Tracking number: " << tagID << endl;
    		cout << "Name: " << name << endl;
    		cout << "Is Nursing(1 for yes, 0 for no): " << nurse << endl << endl;
    		cin.ignore();		//We use the cin.ignore() function because we are going from cin to getline, without this "==>" appears twice

    		//We will run this loop until the user types 'Y' , 'y' , 'N' , 'n'
    		while (!isValidConfirmation) {
    			cout << "(y/n) ==>";
    			getline(cin,entryConfirmation);
    			if ((entryConfirmation.compare("Y") == 0) || (entryConfirmation.compare("y") == 0) || (entryConfirmation.compare("n") == 0) || (entryConfirmation.compare("N") == 0)) {
    				isValidConfirmation = true;
    			}
    		}
    		//If the user chose yes then we will add a bat to the list
    		if ((entryConfirmation.compare("Y") == 0) || (entryConfirmation.compare("y") == 0)) {
    			newBat = new Bat;				//we create a new instance of bat
    			newBat->SetID(tagID);			//we add its tracking number
    			newBat->SetName(name);			//we add its name
    			newBat->SetNurse(nurse);		//we add if it is nursing
        		animalList.push_back(newBat);	//we add the bat to the list
        		cout << "Animal Added to system" << endl;		//we confirm to the user that we added the bat
    		}
    		else {
    			cout << "Action Canceled" << endl;		//we cancel the input then return to the main menu
    		}
    	}
    	else if (animalChoice.compare("2") == 0) {
    		//If the user typed in '2' then we will run this section
    		while ((nurse != 0) && (nurse != 1)){							//The user must enter a 1 or a 0 for nursing
    			cout << "Is the SeaLion nursing? (1 for yes, 0 for no):";
    		    cin >> nurse;
    		}

    		//We repeat the information that we got from the user back to them
    		//Then we will ask for confirmation that they want to add this animal into the list
    	    cout << "Please Confirm, We are adding a SeaLion to the system" << endl;
    	    cout << "Tracking number: " << tagID << endl;
    	    cout << "Name: " << name << endl;
    	    cout << "Is Nursing(1 for yes, 0 for no): " << nurse << endl << endl;
    	    cin.ignore();						//We use the cin.ignore() function because we are going from cin to getline, without this "==>" appears twice

    	    //We will repeat this loop until the user enters 'Y' 'y' 'N' or 'n'
    	    while (!isValidConfirmation) {
    	    	cout << "(y/n) ==>";
    	    	getline(cin,entryConfirmation);
    	    	if ((entryConfirmation.compare("Y") == 0) || (entryConfirmation.compare("y") == 0)|| (entryConfirmation.compare("n") == 0) || (entryConfirmation.compare("N") == 0)) {
    	    		isValidConfirmation = true;
    	    	}
       		}
    	    //If the user chose to add the animal into the system
    	    if ((entryConfirmation.compare("Y") == 0) || (entryConfirmation.compare("y") == 0)) {
        		newSeaLion = new SeaLion;			//We create a new instance of a SeaLion
        		newSeaLion->SetID(tagID);			//We set the tracking number
        		newSeaLion->SetName(name);			//We set the name
        		newSeaLion->SetNurse(nurse);		//We set if it is nursing
        		animalList.push_back(newSeaLion);	//We add the SeaLion to the list
          		cout << "Animal Added to system" << endl;
    	    }
    	    else {
    	    	//If the user chose not to add the animal, we let the user know the action was canceled and we return to the main menu
    	   		cout << "Action Canceled" << endl;
    		}

    	}
    	else if (animalChoice.compare("3") == 0) {
    		//If the user chose '3' then we will enter this block
    		while ((nurse != 0) && (nurse != 1)){				//We will run this loop until the user enters a 1 or 0
    		    cout << "Is the Whale nursing? (1 for yes, 0 for no):";
    			cin >> nurse;
     		}

    		//We repeat the user's entry back to them and ask if they are sure they want to add the animal
    		cout << "Please Confirm, We are adding a Whale to the system" << endl;
       		cout << "Tracking number: " << tagID << endl;
       		cout << "Name: " << name << endl;
       		cout << "Is Nursing(1 for yes, 0 for no): " << nurse << endl << endl;
       		cin.ignore();				//We use this function because we are going from cin to getline.  Without this, the system will type "==>" twice before user entry

       		//We will run this loop until the user enters 'Y' 'y' 'N' or 'n'
       		while (!isValidConfirmation) {
    		    cout << "(y/n) ==>";
    		    getline(cin,entryConfirmation);
    		    if ((entryConfirmation.compare("Y") == 0) || (entryConfirmation.compare("y") == 0) || (entryConfirmation.compare("n") == 0) || (entryConfirmation.compare("N") == 0)) {
    		    	isValidConfirmation = true;
    		   	}
     		}
       		//If the user chose to add the animal into the system
    		if ((entryConfirmation.compare("Y") == 0) || (entryConfirmation.compare("y") == 0)) {
    			newWhale = new Whale;					//we create a new instance of a whale
    			newWhale->SetID(tagID);					//We set the tracking number
    			newWhale->SetName(name);				//We set the name
    			newWhale->SetNurse(nurse);				//We set the nurse value
    			animalList.push_back(newWhale);			//We add the item to the list
    		    cout << "Animal Added to system" << endl;
    		}
    		else {
    			//If the user chose not to add the item to the list, the action is canceled and we return to the main menu
    		    cout << "Action Canceled" << endl;
    		}

    	}
    	else if (animalChoice.compare("4") == 0) {
    		//If the user chose '4' then we enter this block
    		while (numOfEggs < 0){					//We will ask the user for an enter for the number of eggs until the user enters a value of at least 0
    			cout << "How many eggs does the Crocodile have: ";
    			cin >> numOfEggs;
    		}

    		//We list the user's entries back to them then we ask to confirm they would like to add the animal
    		cout << "Please Confirm, We are adding a Crocodile to the system" << endl;
    		cout << "Tracking number: " << tagID << endl;
    		cout << "Name: " << name << endl;
    		cout << "Number of eggs: " << numOfEggs << endl << endl;
    		cin.ignore();						//We use this function because we are going from cin to getline.  Without this, the system will type "==>" twice before user entry

    		//We will run this loop until the user types 'Y' 'y' N' or 'n'
    		while (!isValidConfirmation) {
    			cout << "(y/n) ==>";
    		    getline(cin,entryConfirmation);
    		    if ((entryConfirmation.compare("Y") == 0) || (entryConfirmation.compare("y") == 0) || (entryConfirmation.compare("n") == 0) || (entryConfirmation.compare("N") == 0)) {
    		    	isValidConfirmation = true;
    		   	}
    		}

    		//if the user chose to add the animal to the list, we enter this block
    		if ((entryConfirmation.compare("Y") == 0) || (entryConfirmation.compare("y") == 0)) {
    			newCroc = new Crocodile;				//We create a new instance of Crocodile
    			newCroc->SetID(tagID);					//We set the tracking number
    			newCroc->SetName(name);					//We set the name
    			newCroc->SetNumberOfEggs(numOfEggs);	//We set the number of eggs
    			animalList.push_back(newCroc);			//We add the animal to the list
    			cout << "Animal Added to system" << endl;
    		}
    		else {
    			//If the user chose not to add the animal, then we will exit the loop and go back to the menu
    			cout << "Action canceled" << endl;
    		}

    	}
    	else if (animalChoice.compare("5") == 0) {
    		//If the user chose '5' then we enter this block
    		while (numOfEggs < 0){								//We repeat this loop until the user's entry is at least 0 eggs
    			cout << "How many eggs does the Goose have: ";
    		    cin >> numOfEggs;
    		}
    		cout << "Please Confirm, We are adding a Goose to the system" << endl;
    		cout << "Tracking number: " << tagID << endl;
    		cout << "Name: " << name << endl;
    		cout << "Number of eggs: " << numOfEggs << endl << endl;
    		cin.ignore();					//We use this function because we are going from cin to getline.  Without this, the system will type "==>" twice before user entry

    		// We will repeat this loop until the user enters 'Y' 'y' 'N' or 'n'
    		while (!isValidConfirmation) {
    		    cout << "(y/n) ==>";
    		    getline(cin,entryConfirmation);
    		    if ((entryConfirmation.compare("Y") == 0) || (entryConfirmation.compare("y") == 0) || (entryConfirmation.compare("n") == 0) || (entryConfirmation.compare("N") == 0)) {
    		    	isValidConfirmation = true;
    		    }
    		}
    		//If the user chose to add the animal to the list then we enter this block
    		if ((entryConfirmation.compare("Y") == 0) || (entryConfirmation.compare("y") == 0)) {
    			newGoose = new Goose;					//We create a new instance of Goose
    			newGoose->SetID(tagID);					//We set the tracking number
    			newGoose->SetName(name);				//We set the name
    			newGoose->SetNumberOfEggs(numOfEggs);	//We set the number of eggs
    			animalList.push_back(newGoose);			//We add the goose to the list
    			cout << "Animal Added to system" << endl;
    		}
    		else {
    			//If the user chose not to add the item, then we exit this function and display the main menu
    			cout << "Action canceled" << endl;
    		}
    	}
    	else if (animalChoice.compare("6") == 0) {
    		//If the user chose '6' then we enter this block
    		while (numOfEggs < 0){								//We will have this loop until the user enters at least 0 eggs
    			cout << "How many eggs does the Pelican have: ";
    		    cin >> numOfEggs;
    		}

    		//We read back the entered data back to the user then ask for confirmation
    		cout << "Please Confirm, We are adding a Pelican to the system" << endl;
    		cout << "Tracking number: " << tagID << endl;
    		cout << "Name: " << name << endl;
    		cout << "Number of eggs: " << numOfEggs << endl << endl;
    		cin.ignore();					//We use this function because we are going from cin to getline.  Without this, the system will type "==>" twice before user entry

    		//We will repeat this loop until the user enters 'Y' 'y' 'N' or 'n'
    		while (!isValidConfirmation) {
    			cout << "(y/n) ==>";
    		    getline(cin,entryConfirmation);
    		    if ((entryConfirmation.compare("Y") == 0) || (entryConfirmation.compare("y") == 0) || (entryConfirmation.compare("n") == 0) || (entryConfirmation.compare("N") == 0)) {
    		    	isValidConfirmation = true;
    		    }
    		}

    		//If the user chose to add the item, then we enter this block
    		if ((entryConfirmation.compare("Y") == 0) || (entryConfirmation.compare("y") == 0)) {

    			newPelican = new Pelican;					//We create a new instance of Pelican
    			newPelican->SetID(tagID);					//We set the tracking number
    			newPelican->SetName(name);					//We set the name
    			newPelican->SetNumberOfEggs(numOfEggs);		//We set the number of eggs
    			animalList.push_back(newPelican);			//We add the pelican to the list
    			cout << "Animal Added to system" << endl;
    		}
    		else {
    			//If the user chose not to add the animal, the action is canceled and they return to the main menu
    			cout << "Action Canceled";
    		}
    	}
    	else {
    		//If the user didn't enter '1' , '2' , '3' , '4' , '5' , '6' then we let them know that the choice was invalid
    		isValidAnimalChoice = false;
    		cout << "Invalid Entry" << endl << endl;
    	}
    }
    return animalList;			//We return the updated list
}



//**************************************************************************************************************

//In this module we remove are preparing to remove an animal from the list
//We take in a vector of Animal Pointers and return an int
//The Int that is being returned is the location of the entry we wish to remove

int RemoveAnimal(vector<Animal*> animalList)
{
	string trackingNumber;				//The tracking number that we wish to remove
	bool validInput = false;			//Our test to make sure that the user entered a valid input
	int locationToRemove = -1;			//The location (iteration) of the animal to remove

	//We will stay in this loop until the user enters a valid number
	while (validInput == false){
		validInput = true;				//Value set to true and must be proven false thru checks
		cout << "Input the tracking number for deletion" << endl;
		cout << "==>";
		getline(cin,trackingNumber);

		//If the user just pressed enter, then the user will have to reenter
		if (trackingNumber.size() == 0) {
			validInput = false;
		}

		//If the user entered a tracking number that was too large, then they need to reenter
		if (trackingNumber.size() > 6) {
			validInput = false;
		}

		//This loop adds 0's until the length is 6 digits.  Example: user entered 55, this loop makes it 000055
		if (trackingNumber.size() <6 ){
			while (trackingNumber.size() != 6){
				trackingNumber = "0" + trackingNumber;
			}
		}

		//We check each character for a numeric value 0-9, otherwise the entry is invalid
		if (trackingNumber.size() > 0) {
			for (unsigned int i = 0;i<trackingNumber.size();++i){
				if ((trackingNumber.at(i) != '0') && (trackingNumber.at(i) != '1') && (trackingNumber.at(i) != '2') &&
					(trackingNumber.at(i) != '3') && (trackingNumber.at(i) != '4') && (trackingNumber.at(i) != '5') &&
					(trackingNumber.at(i) != '7') && (trackingNumber.at(i) != '8') && (trackingNumber.at(i) != '9')) {

					validInput = false;
				}
			}
		}
		if (!validInput) {
			cout << endl << "Invalid Input" << endl;
		}
	};

	//We run thru the animalList
	//We compare the user's tracking number entered to the tracking number of the animal.
	//If found, we will set the new location to remove
	for (unsigned int i = 0;i<animalList.size();++i){
		if (trackingNumber.compare(animalList.at(i)->GetID()) == 0){
			locationToRemove = i;
		}
	}

	return locationToRemove;		//We return the location to remove
}



//*************************************************************************************************************

//In this module we will open up the zoodata.txt file and we will read in the data
//We take in no parameters and we return the list

vector<Animal*> LoadDataFromFile()
{
	ifstream inFS;						//The input for our file
	string tagID;						//The tracking number for the animal
	string name;						//The name of the animal
	string type;						//The animal type: Mammal or Oviparous
	string subType;						//The subtype or specific animal type
	Bat* newBat;						//A Bat if the file has a bat in it
	Crocodile* newCroc;					//A Crocodile if the file has a croc in it
	Goose* newGoose;					//A Goose if the file has a goose in it
	Pelican* newPelican;				//A Pelican if the file has a Pelican in it
	SeaLion* newSeaLion;				//A SeaLion if the file has a SeaLion in it
	Whale* newWhale;					//A Whale if the file has a whale in t
	vector<Animal*> animalList;			//A vector of animal pointers
	int numOfEggs;						//Number of eggs for Oviparous animals
	int nurse;							//If the animal is nursing for Mammals

	inFS.open("zoodata.txt");			//We Open the zoodata.txt file
	if (!inFS.is_open()){				//If the file couldn't open, we let the user know
		cout << "Could not open zoodata.txt" << endl;
	}
	else {
		//If the file does open, then we begin the input
		//We run thru this input until the end of the file
		//The file is in a uniform pattern for input
		while (!inFS.eof()){
			inFS >> tagID;				//We input the tracking number
			inFS >> name;				//We input the name
			inFS >> type;				//We input the type

			//If the name had a space in it, we run this check.
			//Example, in the name Goose Lee, when we input type, it would think that type is Lee
			//	so we add Lee to the name and then we enter the type again.
			//  This continues until Oviparous or Mammal is found
			while ((type != "Oviparous") && (type != "Mammal")){
				name = name + " " + type;
				inFS >> type;
			};
			inFS >> subType;			//We input the subtype
			inFS >> numOfEggs;			//We input the number of eggs
			inFS >> nurse;				//We enter the nurse value

			//If the name length was less than 15 characters, then we add spaces until it is 15 characters
			if (name.length()<15){
				while (name.length() < 15){
							name = name + " ";
				}
			}

			//If the type is less than 15 characters, then we add spaces until it is 15 characters
			if (type.length()<15){
				while (type.length() < 15){
					type = type + " ";
				}
			}

			//If the subtype is less than 15 characters, then we add spaces until it is 15 characters
			if (subType.length()<15){
				while (subType.length() < 15){
					subType = subType + " ";
				}
			}

			//If the animal subtype was a bat, then we add a bat to the list
			if (subType == "Bat            "){
				newBat = new Bat;					//We create a new instance of bat
				newBat->SetID(tagID);				//We set the tracking number
				newBat->SetName(name);				//We set the name
				newBat->SetNurse(nurse);			//We set the nurse value
				animalList.push_back(newBat);		//We add the bat to the list of animals
			}
			else if (subType == "Crocodile      "){
				//If the animal subtype was a crocodile, then we add a croc to the list
				newCroc = new Crocodile;			//We create a new instance of Crocodile
				newCroc->SetID(tagID);				//We set the tracking number
				newCroc->SetName(name);				//We set the name
				newCroc->SetNumberOfEggs(numOfEggs);//We set the number of eggs
				animalList.push_back(newCroc);		//We add the animal to the list
			}
			else if (subType == "Goose          "){
				//If the animal subtype was a Goose, then we add a Goose to the list
				newGoose = new Goose;					//We create a new instance of Goose
				newGoose->SetID(tagID);					//We set the tracking number
				newGoose->SetName(name);				//We set the name
				newGoose->SetNumberOfEggs(numOfEggs);	//We set the number of eggs
				animalList.push_back(newGoose);			//We add the animal to the list
			}
			else if (subType == "Pelican        ") {
				//If the animal subtype was a Pelican, then we add a Pelican to the list
				newPelican = new Pelican;				//We create a new instance of Pelican
				newPelican->SetID(tagID);				//We set the tracking number
				newPelican->SetName(name);				//We set the name
				newPelican->SetNumberOfEggs(numOfEggs);	//We set the number of eggs
				animalList.push_back(newPelican);		//We add the animal to the list
			}
			else if (subType == "SeaLion        ") {
				//If the animal subtype was a SeaLion, then we add a SeaLion to the list
				newSeaLion = new SeaLion;			//We create a new instance of SeaLion
				newSeaLion->SetID(tagID);			//We set the tracking number
				newSeaLion->SetName(name);			//We set the name
				newSeaLion->SetNurse(nurse);		//We set the nurse value
				animalList.push_back(newSeaLion);	//We add the animal to the list
			}
			else if (subType == "Whale          ") {
				//If the animal subtype was a whale, then we add a Whale to the list
				newWhale = new Whale;				//We create a new instance of Whale
				newWhale->SetID(tagID);				//We set the tracking number
				newWhale->SetName(name);			//We set the name
				newWhale->SetNurse(nurse);			//We set the value of nurse
				animalList.push_back(newWhale);		//We add the animal to the list
			}
		};


		inFS.close(); //When we are done with the list, we close the file
		cout << "File Loaded." << endl << endl;
	}
	return animalList;  //We return our list
}



//***********************************************************************************************************
//In this module we will open up the zoodata.txt. file and we will overwrite its contencts
//We take in a vector of Aniaml Pointers and return nothing
void SaveDataToFile(vector<Animal*> animalList)
{
     ofstream outFS;			//The variable for our file name
     string dataForFile;		//The data for the file retreived from the PrintToFile function in particular subtype

     outFS.open("zoodata.txt");

     //If we were able to open the file, then we send the contents of our list to the file
     if (outFS.is_open()) {

    	 //We will iterate thru the list one by one
    	 for (unsigned int i = 0; i<animalList.size();++i){
    	 	 dataForFile = animalList.at(i)->PrintToFile();		//We call the PrintToFile() function

    	 	 //If we are on the last iteration, then we will not add another line with endl
    	 	 if (i == (animalList.size()-1)) {
    		 	 outFS << dataForFile;
    	 	 }
    	 	 else {
    	 		 outFS << dataForFile << endl;
    	 	 }
     	 }
    	 cout << "Save Successfully Completed" << endl << endl;		//We let the user know that the save occurred
     }
     else {
    	 //If we cannot open the file, we let the user know
    	 cout << "Unable to open file" << endl;
     }
     outFS.close();  //We close the file

}


//***********************************************************************************************************
//In this module we display the main menu
//We take in no parameters and we return nothing

void DisplayMenu()
{
	 //This is a copy of the menu
	 cout << "-------------------------------------------------" << endl;
     cout << "|   1. Load Animal Data                         |" << endl;
     cout << "|   2. Generate Data                            |" << endl;
     cout << "|   3. Display Animal Data                      |" << endl;
     cout << "|   4. Add Record                               |" << endl;
     cout << "|   5. Delete Record                            |" << endl;
     cout << "|   6. Save Animal Data                         |" << endl;
     cout << "|   7. Quit                                     |" << endl;
     cout << "-------------------------------------------------" << endl << endl;
     cout << "==>";

}


//***********************************************************************************************************
//In this module, we print our list of animals
//We take in a vector of animal Pointers and we return nothing

void PrintList(vector<Animal*> animalList)
{
	cout << endl << endl << endl << endl;
	//If the animal list is not empty, we create the table
	if (animalList.size() > 0) {
		cout << "-------------------------------------------------------------------------------------------" << endl;
		cout << "|Track #   | Name                | Type            | SubType         | Eggs     | Nurse   |" << endl;
		cout << "-------------------------------------------------------------------------------------------" << endl;
		for (unsigned int i = 0;i < animalList.size(); ++i){	//We iterate thru our list
			animalList.at(i)->PrintItem();						//We call the print item function from the subtype
		}
			cout << "-------------------------------------------------------------------------------------------" << endl;
		}
	else {
		//If the list is empty, we let the user know the list is empty
		cout << "Your list is empty" << endl;
	}
}


//***********************************************************************************************************
//The main program

int main()
{
	int itemToRemove;				//variable to be used with the RemoveAnimal() function
	int menuChoice = 0;				//The menu choice from the user used in the switch statement
	string userInput;				//The actual input from the user on the menu choice
	vector<Animal*> animalList;		//Our list of animals

	//We loop until the user chooses to quit the program
	while (menuChoice != 7){
		DisplayMenu();				//We call the DisplayMenu() function
		while (menuChoice == 0){
			getline(cin,userInput);	//We get the user input of menu choice
			if (userInput.size() == 1) {
				if (userInput.compare("1") == 0){
					menuChoice = 1;	//If the user entered 1, then we change the menuChoice to 1
				}
				if (userInput.compare("2") == 0){
					menuChoice = 2;	//If the user entered 2, then we change the menuChoice to 2
				}
				if (userInput.compare("3") == 0){
					menuChoice = 3;	//If the user entered 3, then we change the menuChoice to 3
				}
				if (userInput.compare("4") == 0){
					menuChoice = 4;	//If the user entered 4, then we change the menuChoice to 4
				}
				if (userInput.compare("5") == 0){
					menuChoice = 5;	//If the user entered 5, then we change the menuChoice to 5
				}
				if (userInput.compare("6") == 0){
					menuChoice = 6;	//If the user entered 6, then we change the menuChoice to 6
				}
				if (userInput.compare("7") == 0){
					menuChoice = 7;	//If the user entered 7, then we change the menuChoice to 7
				}
			}

			//If the menuChoice wasn't changed, then we know the user had an invalid input
			if (menuChoice == 0){
				cout << endl << "Invalid Input.  Try Again" << endl;
				cout << "==>";
			}
		};

		//This switch iterates us thru each function
		switch(menuChoice){
			case 1:
				animalList = LoadDataFromFile();	//Case 1 is to load data from zoodata.txt file
				menuChoice = 0;						//We reset the menuChoice so we can reenter the loop
				break;

			case 2:
				GenerateData();						//We call the generate data function that was created in Java
				menuChoice = 0;						//We reset the menuChoice so we can reenter the loop
				break;

			case 3:
				PrintList(animalList);				//We call the print list function
				menuChoice = 0;						//We reset the menuChoice so we can reenter the loop
				break;

			case 4:
				animalList = AddAnimal(animalList);	//We call the add animal function
				menuChoice = 0;						//We reset the menuChoice so we can reenter the loop
				break;

			case 5:
				itemToRemove = RemoveAnimal(animalList);	//We call the remove animal function to find the proper animal to remove
				if (itemToRemove != -1){					//There was a match, then itemToRemove is the location of the item to remove

					//We show the Tracking number and name of the animal they wish to remove from the system
					userInput = "";							//We reset the value of userInput
					cout << "Just to confirm, you would like to remove:" << endl;
					cout << animalList.at(itemToRemove)->GetID() << "     " << animalList.at(itemToRemove)->GetName() << endl;

					//We will loop until the user types 'Y' 'y' 'N' or 'n'
					while ((userInput.compare("Y") != 0) && (userInput.compare("y") != 0) && (userInput.compare("N") != 0) && (userInput.compare("n") != 0)) {
						cout << "(y/n) ==>";
						getline(cin,userInput);
					}

					//If they chose 'Y' or 'y' then we delete the item
					if ((userInput.compare("Y") == 0) || (userInput.compare("y") == 0)){
						animalList.erase(animalList.begin()+itemToRemove);		//We erase from the beginning of the list + the location of the item to remove
						cout << "Animal Successfully Deleted" << endl << endl;
					}
					else
					{
						//If the user chose not to delete the item
						cout << "Action Canceled" << endl << endl;
					}

				}
				else
				{
					//If itemToRemove was -1, then that ID number was not found in the system
					cout << "No such Tracking Number in the system" << endl << endl;
				}
				menuChoice = 0;						//We reset the menuChoice so we can reenter the loop
				break;

			case 6:
				SaveDataToFile(animalList);
				menuChoice = 0;						//We reset the menuChoice so we can reenter the loop
				break;

			case 7:
				break;
		}

	};

	//If the user chose to quit, this is the end message
	cout << endl << "Program Terminated.  Have a good day" << endl;

	return 0;
}
