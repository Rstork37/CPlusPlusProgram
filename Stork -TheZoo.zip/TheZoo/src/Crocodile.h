/*
 * Crocodile.h
 *
 *  Created on: Aug 11, 2020
 *      Author: Ryan Stork
 *      Detail: This is the class definition of Crocodile
 */


#include "Oviparous.h"
#include <string>
using namespace std;


#ifndef CROCODILE_H_
#define CROCODILE_H_

class Crocodile : public Oviparous {			//Crocodile is a class derived from the Oviparous class
public:
	void PrintItem();							//Prints the contents of the animal in a formatted version for our list
	string GetSubType() const;					//Returns "Crocodile      ", which is the animal subtype
	string PrintToFile() const;					//Returns a string of all the data to be saved to zoodata.txt


};



#endif /* CROCODILE_H_ */
