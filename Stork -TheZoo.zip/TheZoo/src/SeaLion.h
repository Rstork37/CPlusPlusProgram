/*
 * SeaLion.h
 *
 *  Created on: Aug 11, 2020
 *      Author: Ryan Stork
 *      Detail: This is the class definition of SeaLion
 */

#include "Mammal.h"
#include <string>

#ifndef SEALION_H_
#define SEALION_H_

class SeaLion : public Mammal {			//SeaLion is a class derived from the Mammal Class
	public:
		void PrintItem();				//Prints the contents of the SeaLion in a formatted version for our list
		string GetSubType() const;		//Returns "SeaLion          " which is the subtype
		string PrintToFile() const;		//Returns a string of all the data to be saved to zoodata.txt
};



#endif /* SEALION_H_ */
