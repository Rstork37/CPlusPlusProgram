/*
 * Mammal.cpp
 *
 *  Created on: Aug 11, 2020
 *      Author: Ryan Stork
 *      Detail: This is the functions of the Mammal Class
 */

#include <iostream>
#include <string>
#include "Mammal.h"
using namespace std;


//Default Constructor
Mammal::Mammal(){
	nurse = 0;
}

//Prints the protected members to the screen
void Mammal::PrintItem(){
	cout << tagID << "     Mammal" << name << "   " << nurse << endl;
}

//Returns the animal type, in this case: Mammal
string Mammal::GetType() const {
	return "Mammal         ";
}

//Sets the value of nurse
void Mammal::SetNurse(int nurse){
	this->nurse = nurse;
}

//Returns the value of nurse
int Mammal::GetNurse() const {
	return nurse;
}
