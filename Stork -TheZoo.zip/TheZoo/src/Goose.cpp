/*
 * Goose.cpp
 *
 *  Created on: Aug 11, 2020
 *      Author: Ryan Stork
 *      Detail: These are the methods of Whale.h
 *      			PrintItem() - Prints a formatted version of the data for the DisplayAnimalData() function
 *      			GetSubType() - Returns the subtype of the animal
 *      			PrintToFile() - Returns a string of all data members to be printed to a file
 */

#include <string>
#include <iostream>
#include "Goose.h"

//Prints the formatted version for the DisplayAnimalData() function
//This Overrides Animal::PrintItem()
void Goose::PrintItem() {
	cout << "| " << tagID << "   | " << name << "     | "
		 << GetType() << " | " << GetSubType() << " | " << numberOfEggs
		 << "        | 0       |" << endl;
}

//Returns the animal subtype
string Goose::GetSubType() const {
	return "Goose          ";
}

//Returns a string of all of the data in the class to be saved to a file
//This overrides Animal::PrintToFile
string Goose::PrintToFile() const {
	string allData;
	allData = tagID + " " + name + "Oviparous      " + "Goose          " + to_string(numberOfEggs) + " 0";
	return allData;
}
