/*
 * SeaLion.cpp
 *
 *  Created on: Aug 11, 2020
 *      Author: Ryan Stork
 *      Detail: These are the methods of SeaLion.h
 *      			PrintItem() - Prints a formatted version of the data for the DisplayAnimalData() function
 *      			GetSubType() - Returns the subtype of the animal
 *      			PrintToFile() - Returns a string of all data members to be printed to a file
 */

#include <string>
#include <iostream>
#include "SeaLion.h"
using namespace std;

//Prints the formatted version for the DisplayAnimalData() function
//This Overrides Animal::PrintItem()
void SeaLion::PrintItem(){
	cout << "| " << tagID << "   | " << name << "     | "
		 << GetType() << " | " << GetSubType() << " | 0        | "
		 << nurse << "       |" << endl;
}

//Returns the animal subtype
string SeaLion::GetSubType() const {
	return "SeaLion        ";
}

//Returns a string of all of the data in the class to be saved to a file
string SeaLion::PrintToFile() const {
	string allData;
	allData = tagID + " " + name + "Mammal         " + "SeaLion        " +   "0 " + to_string(nurse);
	return allData;
}
