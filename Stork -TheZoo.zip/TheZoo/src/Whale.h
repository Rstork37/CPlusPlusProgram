/*
 * Whale.h
 *
 *  Created on: Aug 11, 2020
 *      Author: 1525820_snhu
 */

#include "Mammal.h"
#ifndef WHALE_H_
#define WHALE_H_

class Whale : public Mammal {			//Whale is a class derived from the mammal Class
	public:
		void PrintItem();				//Prints the contents of the Whale in a formatted version for our list
		string GetSubType() const;		//Returns "Whale          " which is the subtype
		string PrintToFile() const;		//Returns a string of all the data to be saved to zoodata.txt
};



#endif /* WHALE_H_ */
