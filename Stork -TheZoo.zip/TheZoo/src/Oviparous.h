/*
 * Oviparous.h
 *
 *  Created on: Aug 11, 2020
 *      Author: Ryan Stork
 *      Detail: The class definition of Oviparous
 */

#include "Animal.h"
#include <string>

#ifndef OVIPAROUS_H_
#define OVIPAROUS_H_

class Oviparous : public Animal {					//A new class derived from the Animal Class
	public:
		Oviparous();								//Default Constructor
		void PrintItem();							//Print the contents of the Oviparous to the screen
		void SetNumberOfEggs(int numberOfEggs);		//Set the number of eggs
		string GetType() const;						//Returns "Oviparous      ", which is the animal type
		int GetNumberOfEggs() const;				//Returns the number of eggs for the oviparous

	protected:
		int numberOfEggs;							//The number of eggs for the oviparous
};



#endif /* OVIPAROUS_H_ */
