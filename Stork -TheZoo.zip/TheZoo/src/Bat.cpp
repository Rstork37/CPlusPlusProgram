/*
 * Bat.cpp
 *
 *  Created on: Aug 11, 2020
 *      Author: Ryan Stork
 *      Detail: These are the methods of Bat.h
 *      			PrintItem() - Prints a formatted version of the data for the DisplayAnimalData() function
 *      			GetSubType() - Returns the subtype of the animal
 *      			PrintToFile() - Returns a string of all data members to be printed to a file
 */

#include <string>
#include <iostream>
#include "Bat.h"
using namespace std;


//Prints the formatted version for the DisplayAnimalData() function
//This Overrides Animal::PrintItem()
void Bat::PrintItem(){
	cout << "| " << tagID << "   | " << name << "     | "
		 << GetType() << " | " << GetSubType() << " | 0        | "
		 << nurse << "       |" << endl;
}

//Returns the animal subtype
string Bat::GetSubType() const {
	return "Bat            ";
}


//Returns a string of all of the data in the class to be saved to a file
string Bat::PrintToFile() const {
	string allData;
	allData = tagID + " " + name + "Mammal         " + "Bat            " +   "0 " + to_string(nurse);
	return allData;
}
