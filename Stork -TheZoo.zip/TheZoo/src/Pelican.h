/*
 * Pelican.h
 *
 *  Created on: Aug 11, 2020
 *      Author: Ryan Stork
 *      Detail: This is the class definition of Pelican
 */

#include <string>
#include "Oviparous.h"
using namespace std;

#ifndef PELICAN_H_
#define PELICAN_H_

class Pelican : public Oviparous {					//Pelican is a class derived from the Oviparous class
	public:
		void PrintItem();							//Prints the contents of the animal in a formatted version for our list
		string GetSubType() const;					//Returns "Pelican        ", which is the subtype
		string PrintToFile() const;					//Returns a string of all the data to be saved to zoodata.txt
};



#endif /* PELICAN_H_ */
