/*
 * Mammal.h
 *
 *  Created on: Aug 11, 2020
 *      Author: Ryan Stork
 *      Detail: The class definition of Mammal
 */

#include "Animal.h"
#include <string>
#ifndef MAMMAL_H_
#define MAMMAL_H_

class Mammal : public Animal {		//We are making a new class derived from Animal Class
	public:
		Mammal();					//Default Constructor
		void PrintItem();			//Prints the protected members to the screen
		void SetNurse(int nurse);	//Sets the Value of nurse
		string GetType() const;		//Returns the type of animal
		int GetNurse() const;		//Returns the value of nurse

	protected:
		int nurse;					//Represents whether or not the mammal is nursing.  1 for yes, 0 for no
};



#endif /* MAMMAL_H_ */
