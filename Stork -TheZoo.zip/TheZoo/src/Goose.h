/*
 * Goose.h
 *
 *  Created on: Aug 11, 2020
 *      Author: Ryan Stork
 *      Detail: This is the class definition of Goose
 */


#include <string>
#include "Oviparous.h"

#ifndef GOOSE_H_
#define GOOSE_H_

class Goose : public Oviparous {					//Goose is a class derived from the Oviparous class
	public:
		void PrintItem();							//Prints the contents of the animal in a formatted version for our list
		string GetSubType() const;					//Returns "Goose          ", which is the subtype
		string PrintToFile() const;					//Returns a string of all the data to be saved to zoodata.txt
};



#endif /* GOOSE_H_ */
