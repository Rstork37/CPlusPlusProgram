/*
 * Bat.h
 *
 *  Created on: Aug 11, 2020
 *      Author: Ryan Stork
 *      Detail: This is the class definition of Bat
 */

#include "Mammal.h"
#include <string>
using namespace std;

#ifndef BAT_H_
#define BAT_H_

class Bat : public Mammal {				//Bat is a class derived from the Mammal class
	public:
		void PrintItem();				//Prints the contents of the bat in a formatted version for our list
		string GetSubType() const;		//Returns "Bat           " which is the subtype
		string PrintToFile() const;		//Returns a string of all the data to be saved to zoodata.txt
};



#endif /* BAT_H_ */
