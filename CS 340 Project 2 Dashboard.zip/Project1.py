#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Jan 31 20:37:08 2021

@author: 1525820_snhu, Ryan Stork

"""
from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """CRUD operations for animal collection in MongoDB """
    
    """
    This is the constructor.  
    parameters:
        self - The current instance of the class
        username - The username supplied by the user
        password - The password supplied by the user
    
    returns:
        nothing
    
    We query the database for the for the username and password given by the user    
    Then we set the database, in this case to AAC
    """
    def __init__(self,username,password): 
        self.client = MongoClient('mongodb://%s:%s@localhost:37782/?authMechanism=DEFAULT&authSource=AAC' % (username,password))
        self.database = self.client['AAC']

#############################################################################   
    
    """
    The is the create function of the CRUD.
    parameters:
        self - The current instance of the class
        searchCriteria - This is the criteria that we will search, in JSON format
        
    returns:
        True - When we were able to add the item to the database
        Exception - When the searchCriteria is empty
        
    We check to make sure that there is criteria to input before we input
    We then do the instert_one to insert the document to the collection
    Then we return
    """    
    def create(self,searchCriteria):
        if searchCriteria is not None:
            self.database.animals.insert_one(searchCriteria)
            return True
        else:
            raise Exception("Nothing to save because data parameter is empty")
            return False
            
 #############################################################################
 
    """
    This is the read function of CRUD
    parameters:
        self - The current instance of the class
        searchCriteria - This is the criteria that will be searched in the function, in JSON format
        
    returns:
        posts - This is a cursor object from mongo, it contains all of the items that matched
                the search criteria
        Exception - When the searchCriteria is left blank
        
    In this function we test to make sure that the searchCriteria is not blank
    Then we do the search and return the results of the search
    """    
    def read(self,searchCriteria):
        if searchCriteria is not None:
            posts = self.database.animals.find(searchCriteria,{"_id":False})
            return posts
        else:
            raise Exception("Nothing to view because data is empty")
        
#############################################################################

    """
    This is the update function of CRUD
    parameters:
        self - The current instance of the class
        searchCriteria - This is the search criteria of the item that we are going to update, in JSON format
                         You must be specific, or you may update the wrong document
        updateCriteria - This is the criteria that we are updating on the specific document, in JSON format
        
    returns: 
        post - The item that was just updated, showing the update has occurred
        Exception - The search criteria must contain information, or an error will be thrown
            
    We first test to make sure that search criteria has information
    Then we upate the document
    Then we return the document that we just updated, showing the update
    """
        
    def update(self,searchCriteria,updateCriteria):
        if searchCriteria is not None:
            self.database.animals.update_one(searchCriteria,updateCriteria)
        else:
            raise Exception("Nothing to update because Search Criteria is empty")
        
        post = self.database.animals.find_one(searchCriteria)
        return post
    
############################################################################# 
        
    """
    This is the delete function of CRUD
    parameters:
        self - The current instance of the class
        searchCriteria - this is the criteria that will be searched for the document to delete
                         Be specific.  Otherwise the wrong document may be deleted.
        
    returns:
        post - This is the item that we found and deleted
        Exception - If searchCriteria is blank, this will cause an error
        
    We test to make sure searchCriteria is not empty
    Then we find the document that will be deleted
    Then we delete the post
    Then we return the document that was just deleted to show the user what was deleted
    """
    
    def delete(self,searchCriteria):
        if searchCriteria is not None:
            post = self.database.animals.find_one(searchCriteria)
            self.database.animals.delete_one(searchCriteria)
            return post
        else:
            raise Exception("Nothing to delete because Search Criteria is empty")
            