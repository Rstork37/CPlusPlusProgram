// CS405 Module 5 Encryption Ryan Stork.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#define _CRT_SECURE_NO_WARNINGS
#include <cassert>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>
#include <time.h>

/// <summary>
/// encrypt or decrypt a source string using the provided key
/// </summary>
/// <param name="source">input string to process</param>
/// <param name="key">key to use in encryption / decryption</param>
/// <returns>transformed string</returns>
std::string encrypt_decrypt(const std::string& source, const std::string& key)
{
    // get lengths now instead of calling the function every time.
    // this would have most likely been inlined by the compiler, but design for perfomance.
    const auto key_length = key.length();
    const auto source_length = source.length();

    // assert that our input data is good
    assert(key_length > 0);
    assert(source_length > 0);

    std::string output = source;

    // loop through the source string char by char
    for (size_t i = 0; i < source_length; ++i)
    { // TODO: student need to change the next line from output[i] = source[i]
      // transform each character based on an xor of the key modded constrained to key length using a mod
        output[i] = source[i] ^ key[i % key_length];        // Performing the XOR Encryption based on the current key
    }

    // our output length must equal our source length
    assert(output.length() == source_length);

    // return the transformed string
    return output;
}

std::string read_file(const std::string& filename)
{
    std::string file_text = "";

    // TODO: implement loading the file into a string
    std::ifstream myfile;                               // Create an input file stream
    myfile.open(filename);                              // Open the file
    if (myfile.is_open()) {                             // If the file actually opened, then we will input data
        while (!myfile.eof()) {                         // We will read until the end of the file
            std::string the_input;                      // Create the current line of text as a string
            std::getline(myfile,the_input);             // We get the whole line all at once
            file_text = file_text + the_input + "\n";   // We add the input to our string, adding a new line at the end
        }
    }
    myfile.close();

    return file_text;
}

std::string get_student_name(const std::string& string_data)
{
    std::string student_name;

    // find the first newline
    size_t pos = string_data.find('\n');
    // did we find a newline
    if (pos != std::string::npos)
    { // we did, so copy that substring as the student name
        student_name = string_data.substr(0, pos);
    }

    return student_name;
}

void save_data_file(const std::string& filename, const std::string& student_name, const std::string& key, const std::string& data)
{
    //  TODO: implement file saving
    //  file format
    //  Line 1: student name
    //  Line 2: timestamp (yyyy-mm-dd)
    //  Line 3: key used
    //  Line 4+: data

    std::time_t rawtime;                            // Create an instance of time
    tm* timeinfo = nullptr;                         // Create a pointer of the tm struct
    std::ofstream myfile;                           // Create a file open stream for writing

    time(&rawtime);                                 // Use the time function to get the time in seconds since January 1, 2000
    timeinfo = localtime(&rawtime);                 // Turn the rawtime into local time

    myfile.open(filename);                          // Open the file for writing
        myfile << student_name << std::endl;        // Write the studen Name
        myfile << asctime(timeinfo) << std::endl;   // Write the current time, formatted
        myfile << key << std::endl;                 // Write the key used
        myfile << data;                             // Write the data
    myfile.close();                                 // Close the file
}

int main()
{
    std::cout << "Encyption Decryption Test!" << std::endl;

    // input file format
    // Line 1: <students name>
    // Line 2: <Lorem Ipsum Generator website used> https://pirateipsum.me/ (could be https://www.lipsum.com/ or one of https://www.shopify.com/partners/blog/79940998-15-funny-lorem-ipsum-generators-to-shake-up-your-design-mockups)
    // Lines 3+: <lorem ipsum generated with 3 paragraphs> 
    //  Danish fontina st. agur blue cheese monterey jack. Blue castello bavarian bergkase cheese strings brie melted cheese ricotta boursin everyone loves. Ricotta fondue roquefort croque monsieur cream cheese cut the cheese babybel paneer. Cheese and wine.
    //  Stilton cheesecake babybel. Squirty cheese cheeseburger cheese and wine chalk and cheese hard cheese jarlsberg fromage frais everyone loves. Hard cheese dolcelatte brie chalk and cheese mascarpone croque monsieur cheese slices pepper jack. Mozzarella edam.
    //  Feta swiss squirty cheese. Cheese on toast macaroni cheese port-salut taleggio mozzarella cheese on toast jarlsberg edam. Queso danish fontina chalk and cheese rubber cheese edam bavarian bergkase feta stinking bishop. Chalk and cheese ricotta fromage dolcelatte when the cheese comes out everybody's happy halloumi red leicester mascarpone. Who moved my cheese ricotta.

    const std::string file_name = "inputdatafile.txt";
    const std::string encrypted_file_name = "encrypteddatafile.txt";
    const std::string decrypted_file_name = "decrytpteddatafile.txt";
    const std::string source_string = read_file(file_name);
    const std::string key = "password";

    // get the student name from the data file
    const std::string student_name = get_student_name(source_string);

    // encrypt sourceString with key
    const std::string encrypted_string = encrypt_decrypt(source_string, key);

    // save encrypted_string to file
    save_data_file(encrypted_file_name, student_name, key, encrypted_string);

    // decrypt encryptedString with key
    const std::string decrypted_string = encrypt_decrypt(encrypted_string, key);

    // save decrypted_string to file
    save_data_file(decrypted_file_name, student_name, key, decrypted_string);

    std::cout << "Read File: " << file_name << " - Encrypted To: " << encrypted_file_name << " - Decrypted To: " << decrypted_file_name << std::endl;

    // students submit input file, encrypted file, decrypted file, source code file, and key used
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu


// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
