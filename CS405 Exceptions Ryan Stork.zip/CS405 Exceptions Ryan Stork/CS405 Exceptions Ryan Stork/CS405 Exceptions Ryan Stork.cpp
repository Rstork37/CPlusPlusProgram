// CS405 Exceptions Ryan Stork.cpp : This file contains the 'main' function. Program execution begins and ends there.
// Author:  Ryan Stork
// Date:    3/28/2021
// Southern New Hampshire University
//

#include <iostream>
#include <stdexcept>
#include <exception>

bool do_even_more_custom_application_logic()
{
    // TODO: Throw any standard exception
    std::string("abc").substr(10); //Throwing a standard string exception
    std::cout << "Running Even More Custom Application Logic." << std::endl;

    return true;
}
void do_custom_application_logic()
{
    // TODO: Wrap the call to do_even_more_custom_application_logic()
    //  with an exception handler that catches std::exception, displays
    //  a message and the exception.what(), then continues processing

    // I made a try and catch block then when do_even_more_custom_application_logic throws an error, it is caught here and displayed.
    std::cout << "Running Custom Application Logic." << std::endl;
    try {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (std::exception& e) {
        std::cout << "Exception Occurred\n" << e.what() << std::endl;
    }
    // TODO: Throw a custom exception derived from std::exception
    //  and catch it explictly in main
    throw ("I couldn't do what was expected");      //Throwing a custom exception to be caught in main
    std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
    // TODO: Throw an exception to deal with divide by zero errors using
    //  a standard C++ defined exception

    // Creating a runtime error so that we cannot divide by zero
    if (den == 0) {
        throw std::runtime_error("Math Error.  Cannot divide by 0\n");
    }
    
    return num / den;
}

void do_division() noexcept
{
    //  TODO: create an exception handler to capture ONLY the exception thrown
    //  by divide.

    float numerator = 10.0f;
    float denominator = 0;

    // A try/catch block when attempt to divide by 0 is done, it thorws an exception.
    try {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (std::runtime_error& e) {
        std::cout << "Exception Occurred" << std::endl << e.what();
    }
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    // TODO: Create exception handlers that catch (in this order):
    //  your custom exception
    //  std::exception
    //  uncaught exception 
    //  that wraps the whole main function, and displays a message to the console.
    try {
        do_division();
        do_custom_application_logic();
    }
    catch (std::runtime_error& e) {
        std::cout << "Exception Occurred" << std::endl << e.what();
    }
    catch (std::exception& e) {
        std::cout << "A standard exception has occurred\n" << e.what();
    }
    catch (...) {
        std::cout << "Caught an uncaught exception\n";
    }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu


// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
