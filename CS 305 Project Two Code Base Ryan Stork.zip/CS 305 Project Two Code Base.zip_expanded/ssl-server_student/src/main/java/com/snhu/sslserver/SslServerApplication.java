//@Author: Ryan Stork
//		   CS305 Module 5 Cipher
//         2/5/2021
//         Southern New Hampshire University
package com.snhu.sslserver;

import org.apache.catalina.connector.Connector;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;


@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}
	


}
//FIXME: Add route to enable check sum return of static data example:  String data = "Hello World Check Sum!";
@RestController
class ServerController{    
    @RequestMapping("/hash")
    public String myHash() throws NoSuchAlgorithmException {
    	String data = "Hello World Check Sum!";
    	MessageDigest shaDigest = MessageDigest.getInstance("SHA-256");
		byte[] inputBytes = data.getBytes();
		byte[] hashBytes = shaDigest.digest(inputBytes);
		String checkSumValue = bytesToHex(hashBytes);
        String dataBlock = "<p>Ryan Stork<br>" + 
        				   "<p>data:"+ data + 
        				   "<br><br><br>Name of Cipher Algorithm used: SHA-256" + 
        				   " CheckSum Value: " + checkSumValue;
        return dataBlock;
    }
    
    public static String bytesToHex(byte[] bytes) {
        StringBuilder hexString = new StringBuilder();
        for (byte hashByte : bytes) {
            int intVal = 0xff & hashByte;
            if (intVal < 0x10) {
                hexString.append('0');
            }
            hexString.append(Integer.toHexString(intVal));
        }
        return hexString.toString();
    }
    
	private Connector redirectConnector() {
		  Connector connector = new Connector("org.apache.coyote.http11.Http11NioProtocol");
		  connector.setScheme("http");
		  connector.setPort(8080);
		  connector.setSecure(false);
		  connector.setRedirectPort(8443);
		  return connector;
		}

}